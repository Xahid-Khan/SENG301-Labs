package cards;

/**
 * The suits in a standard deck.
 */
public enum Suit {
    CLUBS, DIAMONDS, HEARTS, SPADES;
}