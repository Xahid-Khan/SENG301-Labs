package cards;

/**
 * Crude representation of playing cards.
 */
public class Card {
    private final Suit suit;
    private final Rank value;

    public Card(Rank value, Suit suit) {
        this.value = value;
        this.suit = suit;
    }

    public Suit suit() {
        return suit;
    }

    public Rank value() {
        return value;
    }

    public String toString() {
        return "[" + value + " of " + suit + "]";
    }
}