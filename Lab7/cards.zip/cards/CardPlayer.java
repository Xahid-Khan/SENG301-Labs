package cards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Simple representation of a player in a card game.
 */
public class CardPlayer {
    private String name;
    private List<Card> hand;

    public CardPlayer(String name) {
        this.name = name;
        hand = new ArrayList<Card>();
    }

    public void removeCard(Card c) {
        hand.remove(c);
    }

    public void addCard(Card c) {
        hand.add(c);
    }

    public List<Card> showHand() {
        return Collections.unmodifiableList(hand);
    }

    public String getName() {
        return name;
    }
}
