package uc.seng301.wordleapp.lab5.dictionary;

public abstract class DictionaryQuery {
    public abstract DictionaryResponse guessWord(String query);
}
